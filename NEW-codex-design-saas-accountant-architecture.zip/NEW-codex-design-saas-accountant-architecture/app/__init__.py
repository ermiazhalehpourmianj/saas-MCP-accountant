"""Minimal MCP-ready SaaS accountant application package."""
